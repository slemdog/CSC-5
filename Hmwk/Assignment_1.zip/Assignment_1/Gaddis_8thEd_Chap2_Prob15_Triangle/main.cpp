/* 
 * File:   main.cpp
 * Author: Selim Dogan
 * Created on August 31, 2017, 12:09 AM
 * Purpose: output stars in a triangular pattern
 */

//System Libraries
#include <iostream>     //Input/Output Stream Library
using namespace std;    //Standard Name-Space under which System Libraries Reside

//User Libraries

//Global Constants - Not variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Display/Output all the pertinent variables
      cout<<"   *"<<endl
          <<"  ***"<<endl
          <<" *****"<<endl
          <<"*******"<<endl;
      
    //Exit the program
    return 0;
}