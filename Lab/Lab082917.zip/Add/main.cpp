/* 
 * File:   main.cpp
 * Author: Selim Dogan
 * Created on Month X, 20XX, XX:XX XM
 * Purpose:
 */

//System Libraries
#include <iostream>     //Input/Output Stream Library
using namespace std;    //Standard Name-Space under which System Libraries Reside

//User Libraries

//Global Constants - Not variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    short a,b,c;
    
    //Initialize Variables
    a=20000;
    b=30000;
    
    //Input Data/Variables
    
    //Process or map the inputs to the outputs
    c=a+b;
    
    //Display/Output all the pertinent variables
    cout<<a<<" + "<<b<<" = "<<c<<endl;
    
    //Exit the programs
    return 0;
}