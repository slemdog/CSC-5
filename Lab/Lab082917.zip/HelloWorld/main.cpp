/* 
 * File:   main.cpp
 * Author: Selim Dogan
 * Created on August 29, 2017, 11:27 AM
 * Purpose: Our first program to test the IDE
 */

#include <iostream>
using namespace std;


int main(int argc, char** argv) {
    cout<<"Hello World!"<<endl;
    
    return 0;
}

