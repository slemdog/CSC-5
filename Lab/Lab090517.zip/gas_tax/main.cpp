/* 
 * File:   main.cpp
 * Author: Selim Dogan
 * Created on September 5, 2017, 12:16 PM
 * Purpose:
 */

//System Libraries
#include <iostream>       //Input/Output Stream Library
using namespace std;    //Standard Name-Space under which System Libraries Reside

//User Libraries

//Global Constants - Not variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float gasprce = 3.00;
    float fedtax = 0.184;
    float sttax = 0.36;
    float saletax = 0.08;
    float oilProf = 0.07;
    float totTax;
    float pctOil;
    float pctGas; 
    
    //Initialize Variables
    
    //Input Data/Variables
    
    //Process or map the inputs to the outputs
    totTax = fedtax+sttax+gasprce*saletax
    pctOil
    //Display/Output all the pertinent variables
    
    //Exit the program
    return 0;
}