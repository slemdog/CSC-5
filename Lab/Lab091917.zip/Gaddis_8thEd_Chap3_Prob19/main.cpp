/* 
 * File:   main.cpp
 * Author: Selim Dogan
 * Created on Month X, 20XX, XX:XX XM
 * Purpose: to calculate the monthly payment on a loan
 */

//System Libraries
#include <iostream>       //Input/Output Stream Library
#include <cmath>	//math library for C
using namespace std;    //Standard Name-Space under which System Libraries Reside

//User Libraries

//Global Constants - Not variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned char  nMonth(36);	//number of months
    int loan(10000);	//initial loan amount
    float aInt(0.12f),	//annual interest rate
	  mInt,		//monthly interest rate 
//	  totpaid,	//total amount paid
	  intpaid,	//interest paid
	  mPay;		//monthly payment
	double totpaid;

    //Initialize Variables
    
    //Input Data/Variables
    
    //Process or map the inputs to the outputs
    mInt = aInt/12;
    float intr = exp(nMonth*log(1+mInt));
    mPay = mInt*intr/(intr-1)*loan;
    mPay = static_cast<int>(mPay*100)/100.0f;
    totpaid = 332.14f*nMonth;
    intpaid = totpaid-loan;

    //Display/Output all the pertinent variables
    cout<<mPay<<endl;
    cout<<"your total pay is: $"<<totpaid<<endl;
    cout<<intpaid<<endl;    

    //Exit the program
    return 0;
}
